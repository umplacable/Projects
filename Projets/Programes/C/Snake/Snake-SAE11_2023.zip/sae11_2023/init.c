#include<stdio.h>
#include<stdlib.h>
#include<graph.h>
#include<time.h>

/* On define les directions de déplacement du serpent */
#define UP 0 
#define RIGHT 1 
#define DOWN 2
#define LEFT 3 

/* On define les réponces de certianes fonctions: */
    /* EstOcuper */
    #define YA_RIEN 0
    #define UN_MUR 1
    #define MA_QUEUE 2
    #define A_ROCK 2
    #define UNE_POMME 3

    /* pour rester et sortire de la boucle du main */
    #define IN 1
    #define OUT 0

#define ROCKS 50
#define POMMES 5
#define S_TAILLE 10
#define CYCLE 100000L
#define SECONDS 1000000L

/* Les valeurs de X et Y ou il y a un GUI*/
#define GUIOFSET_DOWN 20
#define GUIOFSET_X 20
#define GUIOFSET_X2 GUIOFSET_X+960
#define GUIOFSET_Y 20
#define GUIOFSET_Y2 GUIOFSET_Y+640
#define L 960+(2*GUIOFSET_X)
#define H 640+(2*GUIOFSET_Y)+GUIOFSET_DOWN

typedef char* FilePath;

struct Snake{       /* structure du snake */
    unsigned x;
    unsigned y;
    int direction;
    struct Snake* next;
};
typedef struct Snake Snake;

struct SnakeEnd{    /* structure de la fin du snake */
    unsigned x;
    unsigned y;
};
typedef struct SnakeEnd SnakeEnd;

struct Pomme{       /* structure de la pomme */
    unsigned x;
    unsigned y;
    struct Pomme *next;
};
typedef struct Pomme Pomme;

struct Rock{
    unsigned x;
    unsigned y;
    struct Rock *next;
};
typedef struct Rock Rock;

struct Texture{     /* structure des textures du snake */
    int up;
    int right;
    int down;
    int left;
};
typedef struct Texture Texture;

struct Timer_S{     /* structure du temp */
    int sec;
    int min;
    int heur;
};
typedef struct Timer_S Timer_S;

struct Score{       /* structure du Score */
    short un;
    short di;
    short cen;
    short mil;
    short milon;
};
typedef struct Score Score;

void InitialiseEcran(){ /* on initialise l'écrant ( graphique + fenetre ) */

    InitialiserGraphique(); /* graphique */
    CreerFenetre(10,10,L,H);/* fenetre */
}

Snake* InitialiseSnake(){   /* on initialise le snake de la taille S_TAILLE */
    int i=0;
    Snake *Serpent = (Snake*) malloc(sizeof(Snake)), *p ;

    Serpent->x = GUIOFSET_X + 30*16; /* La coordonnées de la tête (x) au milieu */
    Serpent->y = GUIOFSET_Y + 15*16; /* La coordonnées de la tête (y) a */
    Serpent->direction = UP;       /* La direction du serpent est arbitraire et ne peut être changer */
    
    for ( p = Serpent; i < (S_TAILLE-1); p=p->next){
        Snake *suiv= (Snake*)malloc(sizeof(Snake));  /* Allouer de la mémoire pour chaque élément */
        suiv->x = GUIOFSET_X + 30*16;     /* La coordonnées de la tête (x) au milieu */
        suiv->y = GUIOFSET_Y + (16+i)*16; /* La coordonnées de la tête (y) a la position 16+i */
        suiv->direction = UP;           /* La direction du serpent est arbitraire et ne peut être changer */
        suiv->next = NULL;
        p->next = suiv;
        i++;
    }
    p->next = NULL;
    return Serpent;
}

int EstOccuper(int x, int y, Snake *Serpent, Pomme *pomme, Rock *rock){ /* on regarde si la case X Y est occuper par n'importe quoi */
    int i;
    Snake *p;
    Pomme *n;
    Rock *r;
    /* on vérifie si les coordonnés sont bien dans l'espace de jeu */
    if(
        x <= GUIOFSET_X || 
        y <= GUIOFSET_Y || 
        x >= GUIOFSET_X2 ||
        y >= GUIOFSET_Y2
    ){
        return UN_MUR;
    }

    if(Serpent != NULL){
    /* on regarde si la coordonné est une des coordonnés de la queue du serpent */
        for (p=Serpent->next; p->next != NULL; p=p->next)
        {
            if(
                x == p->x &&
                y == p->y
            ){
                return MA_QUEUE;
            }
        }
    }
    
    if(pomme != NULL){
    /* on essaie de sentir si il y a une pomme */
        for (n=pomme; n->next != NULL; n=n->next)
        {
            if(
                x == n->x &&
                y == n->y
            ){
                return UNE_POMME;
            }
        }
    }
    if(rock != NULL){
        for (r=rock; r->next != NULL; r=r->next){
            if (
                x == r->x && 
                y == r->y 
                ){
                return A_ROCK;
            }
        }
    }
    return YA_RIEN;
    
}

Pomme* InitPomme(Snake *Serpent){   /* on initialise les pommes au nombre de POMMES */

    Pomme* pommes = (Pomme*)malloc(sizeof(Pomme)), *p;
    unsigned i=0, x=0, y=0, Occuper;
    Rock* rocks = (Rock*)malloc(sizeof(Rock)), *r;
    

    srand((unsigned)Microsecondes());

    pommes->x = 0;    /* pour éviter les problèmes lier a une lecture de valeurs NULL */
    pommes->y = 0;
    for (p = pommes; i < POMMES; p=p->next){
        Pomme* pomme = (Pomme*)malloc(sizeof(Pomme));  /* on alloue de la mémoire pour chaque pommes*/
        pomme->x = 0;    /* pour éviter les problèmes lier a une lecture de valeurs NULL */
        pomme->y = 0;    /* on initialise les coordonnées des pommes à O */
        pomme->next = NULL;
        p->next = pomme;
        i++;
    }
    i=0;
    p = NULL;
    for (p = pommes; i < POMMES ; p=p->next){
        x = GUIOFSET_X + (16*((rand()%(60 - 0)) + 0)); /* On donne des coordonnées */
        y = GUIOFSET_Y + (16*((rand()%(40 - 0)) + 0)); /* random à x et y */

        Occuper = EstOccuper(x, y, Serpent, pommes, rocks); /* on stock le résultat de EstOccuper() */

        while (
            Occuper == UN_MUR ||        /* on vérifie que notre résultat n'est pas: un mur/bord,*/
            Occuper == UNE_POMME ||     /* une pomme,*/
            Occuper == MA_QUEUE   ||      /* ou une partit de la queue du serpent.*/
            Occuper == A_ROCK 
        ){
            x = GUIOFSET_X + (16*((rand()%(60 - 0)) + 0)); /* On donne des coordonnées */
            y = GUIOFSET_Y + (16*((rand()%(40 - 0)) + 0)); /* random à x et y */

            Occuper = EstOccuper(x, y, Serpent, pommes, rocks); /* on stock le résultat de EstOccuper() */
        }
        p->x = x;    /* enfin on affecte les valeurs de x */
        p->y = y;    /* et y aux coordonnée de la pomme sélectionner */
        i++;
    }



    return pommes;
}


Rock* InitRock(Snake *Serpent, Pomme *pommes){ /* on initialise les pommes au nombre de ROCKS */

    Pomme *p;
    Rock* rocks = (Rock*)malloc(sizeof(Rock)), *r;
    unsigned i=0, x=0, y=0, Occuper;

    rocks->x = 0;
    rocks->y = 0;
    for (r = rocks; i < ROCKS; r=r->next){
        Rock* rock = (Rock*)malloc(sizeof(Rock));  /* on alloue de la mémoire pour chaque rochers*/
        rock->x = 0;    /* pour éviter les problèmes lier a une lecture de valeurs NULL */
        rock->y = 0;    /* on initialise les coordonnées des rochers à O */
        rock->next = NULL;
        r->next = rock;
        i++;
    }
    i=0;
    r = NULL;
    for (r = rocks; i < ROCKS ; r=r->next){
        x = GUIOFSET_X + (16*((rand()%(60 - 0)) + 0)); /* On donne des coordonnées */
        y = GUIOFSET_Y + (16*((rand()%(40 - 0)) + 0)); /* random à x et y */

        Occuper = EstOccuper(x, y, Serpent, pommes, rocks); /* on stock le résultat de EstOccuper() */

        while (
            Occuper == UN_MUR ||        /* on vérifie que notre résultat n'est pas: un mur/bord,*/
            Occuper == UNE_POMME ||     /* une pomme,*/
            Occuper == MA_QUEUE  ||     /* ou une partit de la queue du serpent.*/
            Occuper == A_ROCK           /* ou un caillou*/
        ){
            x = GUIOFSET_X + (16*((rand()%(60 - 0)) + 0)); /* On donne des coordonnées */
            y = GUIOFSET_Y + (16*((rand()%(40 - 0)) + 0)); /* random à x et y */

            Occuper = EstOccuper(x, y, Serpent, pommes, rocks); /* on stock le résultat de EstOccuper() */
        }
        r->x = x;    /* enfin on affecte les valeurs de x */
        r->y = y;    /* et y aux coordonnée du rocher sélectionner */
        i++;
    }
    return rocks;
}


    