#include<stdio.h>
#include<stdlib.h>
#include<graph.h>
#include<time.h>

#include"init.h"


void AfficheBackground(FilePath path){ /* on affiche le background */
    ChoisirEcran(0);
    EffacerEcran(CouleurParNom("black"));
    ChargerImage(path,GUIOFSET_X,GUIOFSET_Y,0,0,960,640);
}

void AfficherSnake(Snake* Serpent, SnakeEnd* ApresQueue, Texture *ImgTete, Texture *ImgCorp, Texture *ImgQueue){
    Snake *p;

    ChoisirEcran(0);

    /* on copie une zone contenue dans l'écrant 1 directement sur l'écrant principal, cette zonne équivaut a une case du plateau de jeu */
    CopierZone(1,0,0,0,16,16, Serpent->x, Serpent->y);
    switch (Serpent->direction){ /* on va afficher la tete du serpent a ces coordonnées et selon sa direction */
        case UP:
            AfficherSprite(ImgTete->up, Serpent->x, Serpent->y);
            break;
        
        case RIGHT:
            AfficherSprite(ImgTete->right, Serpent->x, Serpent->y);
            break;

        case DOWN:
            AfficherSprite(ImgTete->down, Serpent->x, Serpent->y);
            break;
        
        case LEFT:
            AfficherSprite(ImgTete->left, Serpent->x, Serpent->y);
            break;

        default:
            break;
    }

    for (p=Serpent->next; p->next != NULL; p=p->next ){ /* on va afficher tout les corps du serpent a ces coordonnées et selon sa direction */

        /* on copie une zone contenue dans l'écrant 1 directement sur l'écrant principal, cette zonne équivaut a une case du plateau de jeu */
        CopierZone(1,0,0,0,16,16, p->x, p->y);
        switch (p->direction){
            case UP:
                AfficherSprite(ImgCorp->up, p->x, p->y);
                break;
            
            case RIGHT:
                AfficherSprite(ImgCorp->right, p->x, p->y);
                break;

            case DOWN:
                AfficherSprite(ImgCorp->down, p->x, p->y);
                break;
            
            case LEFT:
                AfficherSprite(ImgCorp->left, p->x, p->y);
                break;

            default:
                break;
        }
    }

    /* on copie une zone contenue dans l'écrant 1 directement sur l'écrant principal, cette zonne équivaut a une case du plateau de jeu */
    CopierZone(1,0,0,0,16,16, p->x, p->y); 
        switch (p->direction){/* on va afficher la queue du serpent a ces coordonnées et selon sa direction */
        case UP:
            AfficherSprite(ImgQueue->up, p->x, p->y);
            break;
        
        case RIGHT:
            AfficherSprite(ImgQueue->right, p->x, p->y);
            break;

        case DOWN:
            AfficherSprite(ImgQueue->down, p->x, p->y);
            break;
        
        case LEFT:
            AfficherSprite(ImgQueue->left, p->x, p->y);
            break;

        default:
            break;
            
    }

    /* on copie une zone contenue dans l'écrant 1 directement sur l'écrant principal, cette zonne équivaut a une case du plateau de jeu */
    CopierZone(1,0,0,0,16,16, ApresQueue->x, ApresQueue->y);
}

void AfficheRock(Rock* rocks, int sprite_rocks ){
    Rock *r;
    ChoisirEcran(0);
    for (r=rocks; r->next != NULL; r=r->next ){     
        AfficherSprite(sprite_rocks, r->x, r->y);
    }
}

void AffichePomme(Pomme* pommes, int sprite_pommes){
    Pomme *n;
    ChoisirEcran(0);
    
    for (n=pommes; n->next != NULL; n=n->next ){     /* pour toutes les pommes de la liste chainée pommes,*/
        AfficherSprite(sprite_pommes, n->x, n->y);   /* on l'affiche a sa position (X , Y)  */
    }
}

void RemplacerPomme(Snake* Serpent, Pomme* TabPommes, Rock* TabRock, int SPomme, int SRock, unsigned x, unsigned y){
    int i, Occuper, xr, yr;
    Pomme *p;
    srand(Microsecondes());
    for (p=TabPommes; p->next != NULL; p=p->next){ /* pour toutes les pommes de la liste chainée pommes,*/
        if (
            p->x == x &&                           /* on modifie la pomme de coordonner (X , Y) */
            p->y == y                              /* pour pouvoir la modifier plus tard */
            )
        {
            p->x = 0;
            p->y = 0;
            break;
        }
        
    }
    xr = GUIOFSET_X + (16*((rand()%(60 - 0)) + 0)); /* On donne des coordonnées */
    yr = GUIOFSET_Y + (16*((rand()%(40 - 0)) + 0)); /* random à x et y */

    Occuper = EstOccuper(xr, yr, Serpent, p,TabRock); /* on stock le résultat de EstOccuper() */

    while (
        Occuper == UN_MUR ||        /* on vérifie que notre résultat n'est pas: un mur/bord,*/
        Occuper == UNE_POMME ||     /* une pomme,*/
        Occuper == MA_QUEUE  ||        /* ou une partit de la queue du serpent.*/
        Occuper ==A_ROCK
    ){
        xr = GUIOFSET_X + (16*((rand()%(60 - 0)) + 0)); /* On donne des coordonnées */
        yr = GUIOFSET_Y + (16*((rand()%(40 - 0)) + 0)); /* random à x et y */

        Occuper = EstOccuper(xr, yr, Serpent, p,TabRock); /* on stock le résultat de EstOccuper() */
    }
    
    p->x = xr;    /* enfin on affecte les valeurs de x */
    p->y = yr;    /* et y aux coordonnée de la pomme sélectionner */
    
    AffichePomme(p, SPomme);

}
/* génère une pome en remplacement de celle manger */

void ModifsDansSnake(Snake* Serpent, SnakeEnd* ApresQueue){ 
    /*  c'est une fonction récurcive qui va pendant sa phase descendante 
        parcourir le serpent jusqu'à sa fin et modifier en déplassant 
        tout les atributs du précédant vers la parti du serpent actuel */

    if (Serpent->next->next != NULL){
        ModifsDansSnake(Serpent->next, ApresQueue); /* phase descendante */
    }
    
    if (Serpent->next->next == NULL){               /* phase montante */
        ApresQueue->x = Serpent->next->x;   /* modification de l'après queue */
        ApresQueue->y = Serpent->next->y;
    }
    Serpent->next->x = Serpent->x;
    Serpent->next->y = Serpent->y;          /* modification des atributs du corp */
    Serpent->next->direction = Serpent->direction;
}

void AfficheScore(Score* score){
    char *unit[] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};

    /* on affiche le titre une premierre fois pour évité les flics */
    ChoisirEcran(0);
    ChoisirCouleurDessin(CouleurParNom("white"));  
    EcrireTexte(600, H-10,"Score :   ", 2);

    /* on affiche un carrée plus grand que la taille du texte complet pour l'éfacer puis réécrire par dessus */
    ChoisirCouleurDessin(CouleurParNom("black"));
    RemplirRectangle(600, GUIOFSET_Y2,600+TailleChaineEcran("Score :  ", 2)+TailleChaineEcran(unit[score->milon], 2)+TailleChaineEcran(unit[score->mil], 2)+TailleChaineEcran(unit[score->cen], 2)+TailleChaineEcran(unit[score->di], 2)+ 40, 100);
    
    /* on affiche le titre une deuxieme fois*/
    ChoisirCouleurDessin(CouleurParNom("white"));
    EcrireTexte(600, H-10,"Score :  ", 2);

    /* on affiche les chiffre un a un pour les 5 unitées */
    EcrireTexte(600+TailleChaineEcran("Score :  ", 2), H-9, unit[score->milon], 2);
    EcrireTexte(600+TailleChaineEcran("Score :  ", 2)+TailleChaineEcran(unit[score->milon], 2), H-9, unit[score->mil], 2);
    EcrireTexte(600+TailleChaineEcran("Score :  ", 2)+TailleChaineEcran(unit[score->milon], 2)+TailleChaineEcran(unit[score->mil], 2), H-9, unit[score->cen], 2);
    EcrireTexte(600+TailleChaineEcran("Score :  ", 2)+TailleChaineEcran(unit[score->milon], 2)+TailleChaineEcran(unit[score->mil], 2)+TailleChaineEcran(unit[score->cen], 2), H-9, unit[score->di], 2);
    EcrireTexte(600+TailleChaineEcran("Score :  ", 2)+TailleChaineEcran(unit[score->milon], 2)+TailleChaineEcran(unit[score->mil], 2)+TailleChaineEcran(unit[score->cen], 2)+TailleChaineEcran(unit[score->di], 2), H-9, unit[score->un], 2);
}

int CheckAhead(Snake *Serpent, Pomme *pommes,Rock *rocks, SnakeEnd *ApresQueue, Texture *tete, Texture *corp, Texture *queue, Score *score, int SPomme,int SRock){
    int occuper, i, key;
    Snake* p;
    occuper = EstOccuper(Serpent->x,Serpent->y,Serpent,pommes,rocks); 

    if( occuper == UN_MUR || /* on chec pour voir si le jouer perd et se crachant contre un mur / soi même */
        occuper == MA_QUEUE ||
        occuper == A_ROCK 

    ){
        ChoisirCouleurDessin(CouleurParNom("black"));                                                                   /* on affiche pendant une durée indéterminé */
        RemplirRectangle(GUIOFSET_X, GUIOFSET_Y, 960, 640);                                                             /* l'écrant de Game Over avec une informations  */
        ChoisirCouleurDessin(CouleurParNom("white"));                                                                   /* de touches pour quitté le jeu */
        EcrireTexte(480-(TailleChaineEcran("GAME OVER",2)/2),220,"GAME OVER",2);
        EcrireTexte(480-(TailleChaineEcran("touche <Echap> pour quiter",0)/2),600,"touche <Echap> pour quiter",0);
        
        while (True){ /* on fait une boucle infinit pour ne pas reprendre le jeux alors qu'on est mort */
            key = Touche();
            if (key == XK_Escape){
                return OUT; /* on return OUT pour que la variable end nous face sortir de la boucle du main() */
            }
        }
        printf("2");
        return OUT;
    }
    
    else if( occuper == UNE_POMME ){ /* on chec pour voir si le jouer mange une pomme */
        for( p=Serpent ; p->next != NULL ; p=p->next){} /* on va a la fin du serpent, */
        for (i = 0; i < 2; p = p->next){                /* on r'ajoute deux partis de corp au serpent */
            Snake *suiv = (Snake*)malloc(sizeof(Snake));
            suiv->x = p->x;
            suiv->y = p->y;
            suiv->direction = p->direction;
            suiv->next = NULL;
            p->next = suiv;
            i++;
        }
        score->un = score->un + 5;  /* on r'ajoute 5 points au score */
        if (score->un >= 10){
            score->un -= 10;
            score->di++;
            if (score->di >= 10){
                score->di -= 10;
                score->cen++;
                if (score->cen >= 10){
                    score->cen -= 10;
                    score->mil++;
                    if (score->mil >= 10){
                        score->mil -= 10;
                        score->milon++;
                    }
                }
            }
        }
        AfficheScore(score);                                                /* et on affiche le score */
        AfficherSnake(Serpent,ApresQueue, tete, corp, queue);               /* et le snake */
        RemplacerPomme(Serpent, pommes, rocks, SPomme, SRock,Serpent->x, Serpent->y);
    }
    return IN;              /* on return IN pour que la variable end nous face resté dans la boucle du main() */
}

void DeplacerSnake(Snake* Serpent, SnakeEnd* ApresQueue){
    
    ModifsDansSnake(Serpent,ApresQueue); /* on appel la fonction récurcive ModifDansSnake() pour modifier le snake */

    switch (Serpent->direction){ /* on va modifier les coordonées de la tète du serpent selon la direction de celui-ci */
        case UP:
            Serpent->y -= 16;
            break;

        case RIGHT:
            Serpent->x += 16;
            break;
        
        case DOWN:
            Serpent->y += 16;
            break;

        case LEFT:
            Serpent->x -= 16;
            break;
        
        default:
            break;
    }
}
/* déplace le serpent */

void AfficheTime(Timer_S *TIMER){
    char *chrono[] = {"00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59"} ;

    /* on affiche le titre une premierre fois pour évité les fliks */
    ChoisirEcran(0);
    ChoisirCouleurDessin(CouleurParNom("white"));
    EcrireTexte(120, H-10,"Temps :   ", 2);

    /* on affiche un carrée plus grand que la taille du texte complet pour l'éfacer puis réécrire par dessus */
    ChoisirCouleurDessin(CouleurParNom("black"));
    RemplirRectangle(0, GUIOFSET_Y2,120+TailleChaineEcran("Temps :   ", 2)+TailleChaineEcran(chrono[TIMER->sec], 2)+TailleChaineEcran(" : ", 2)+TailleChaineEcran(chrono[TIMER->min], 2)+TailleChaineEcran(" : ", 2)+TailleChaineEcran(chrono[TIMER->heur], 2)+ 40, 100);
    
    /* on affiche le titre une deuxieme fois*/
    ChoisirCouleurDessin(CouleurParNom("white"));
    EcrireTexte(120, H-10,"Temps :    ", 2);

    /* on affiche le temp dans l'ordre heures ; minutes ; secondes , séparé par des deux points ' : ' */
    EcrireTexte(120+TailleChaineEcran("Temps :   ", 2), H-9, chrono[TIMER->heur], 2);
    EcrireTexte(120+TailleChaineEcran("Temps :   ", 2)+TailleChaineEcran(chrono[TIMER->heur], 2), H-10, " : ", 2);
    EcrireTexte(120+TailleChaineEcran("Temps :   ", 2)+TailleChaineEcran(chrono[TIMER->heur], 2)+TailleChaineEcran(" : ", 2), H-9, chrono[TIMER->min], 2);
    EcrireTexte(120+TailleChaineEcran("Temps :   ", 2)+TailleChaineEcran(chrono[TIMER->heur], 2)+TailleChaineEcran(" : ", 2)+TailleChaineEcran(chrono[TIMER->min], 2), H-10, " : ", 2);
    EcrireTexte(120+TailleChaineEcran("Temps :   ", 2)+TailleChaineEcran(chrono[TIMER->heur], 2)+TailleChaineEcran(" : ", 2)+TailleChaineEcran(chrono[TIMER->min], 2)+TailleChaineEcran(" : ", 2), H-9, chrono[TIMER->sec], 2);
}