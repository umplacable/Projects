#include<stdio.h>
#include<stdlib.h>
#include<graph.h>
#include<time.h>

#include"affiche.h"
#include"init.h"


int Texturing(){
    int key , texturing, skin = 0 ;

    /* GUI pour le choix de la texture */
    CopierZone(0, 2, GUIOFSET_X, GUIOFSET_Y, L, H, 0, 0);   /* sauve l'écrant dans un autre */
    ChoisirCouleurDessin(CouleurParNom("black"));
    RemplirRectangle(300, 170, 400, 300);
    ChoisirCouleurDessin(CouleurParNom("white"));
    EcrireTexte(((L)/2)-(TailleChaineEcran("Choisisez votre serpent :",2)/2),220,"Choisisez votre serpent :",2);    /* GUI pour le choix du skin */
    EcrireTexte(325,260," T - un train",1);
    EcrireTexte(325,300," D - le devoreur de monde",1);

    /* chaques cas de letres demander est doublé pour sa version capitale */
    while(texturing){
        key = Touche();
        switch (key){
            case XK_c:
                skin=3;
                texturing=0;
                break;

            case XK_C:
                skin=3;
                texturing=0;

                break;

            case XK_t:
                skin = 1;
                texturing = 0;
                break;
            
            case XK_T:
                skin = 1;
                texturing = 0;
                break;
                
            case XK_d:
                skin = 2;
                texturing = 0;
                break;
                
            case XK_D:
                skin = 2;
                texturing = 0;
                break;



            default:
            ChoisirCouleurDessin(CouleurParComposante(255, 150, 150));
            EcrireTexte(320,450,"Ce n'est pas une touche legale",1);   /* message d'érreur */
                break;
        }
    }
    CopierZone(2, 0, 0, 0, L, H, GUIOFSET_X, GUIOFSET_Y);   /* remet l'écrant a sa place */
    return skin;
}

int Mode(){
    int key , moding, mode = 0 ;

    /* GUI pour le choix de la texture */
    CopierZone(0, 2, GUIOFSET_X, GUIOFSET_Y, L, H, 0, 0);   /* sauve l'écrant dans un autre */
    ChoisirCouleurDessin(CouleurParNom("black"));
    RemplirRectangle(300, 170, 400, 300);
    ChoisirCouleurDessin(CouleurParNom("white"));
    EcrireTexte(((L)/2)-(TailleChaineEcran("Choisisez votre mode de jeu :",2)/2),220,"Choisisez votre mode de jeu :",2);    /* GUI pour le choix du mode */
    EcrireTexte(325,260," A - avec les rochers",1);
    EcrireTexte(325,300," S - sans les rochers",1);

    /* chaques cas de letres demander est doublé pour sa version capitale */
    while(moding){
        key = Touche();
        switch (key){

            case XK_a:
                mode = 1;
                moding = 0;
                break;
            
            case XK_A:
                mode = 1;
                moding = 0;
                break;
                
            case XK_s:
                moding = 0;
                break;
                
            case XK_S:
                moding = 0;
                break;



            default:
            ChoisirCouleurDessin(CouleurParComposante(255, 150, 150));
            EcrireTexte(320,450,"Ce n'est pas une touche legale",1);   /* message d'érreur */
                break;
        }
    }
    CopierZone(2, 0, 0, 0, L, H, GUIOFSET_X, GUIOFSET_Y);   /* remet l'écrant a sa place */
    return mode;
}

void LibererSpriteAll(Texture *tete, Texture *corp, Texture *queue){    /* pour libérer l'espaces des textures */

    /* pour la tête */
    LibererSprite(tete->down);
    LibererSprite(tete->left);
    LibererSprite(tete->right);
    LibererSprite(tete->up);
    
    /* pour le corp */
    LibererSprite(corp->down);
    LibererSprite(corp->left);
    LibererSprite(corp->right);
    LibererSprite(corp->up);

    /* pour la queue */
    LibererSprite(queue->down);
    LibererSprite(queue->left);
    LibererSprite(queue->right);
    LibererSprite(queue->up);
}

int main(){
int key, SPomme, SRock, end = 1, skin = 0, mode = 0, NextSec = 0, Ahead = IN;

    /* on marque le debut du cycle */
    long unsigned suivant = Microsecondes()+CYCLE;

    /* on initialise toutes les variable dont on va avoir besoin */
    Texture *tete= (Texture*)malloc(sizeof(Texture)),
            *corp= (Texture*)malloc(sizeof(Texture)),
            *queue= (Texture*)malloc(sizeof(Texture));

    Snake* serpent = InitialiseSnake(), *Ssuiv;
    SnakeEnd * ApresQueue = (SnakeEnd*) malloc(sizeof(SnakeEnd));
    
    Pomme* TabPommes = InitPomme(serpent), *Psuiv;

    Rock* TabRock, *Rsuiv;

    Timer_S *TIMER= (Timer_S*)malloc(sizeof(Timer_S));

    Score *score = (Score*)malloc(sizeof(Score));

    /* on charche les chemins de toutes les textures */
    char        *loco_back = "image/loco/loco_back.png", 
                *loco_front = "image/loco/loco_front.png" , 
                *loco_left = "image/loco/loco_left.png" , 
                *loco_right = "image/loco/loco_right.png" , 

                *wagon_top = "image/wagon/wagon_top.png",  
                *wagon_cotes = "image/wagon/wagon_side.png" ,
                
                *DM_T_up= "image/devoreur_de_monde/Tete/devoreur_de_monde_Head_UP.png", 
                *DM_T_right= "image/devoreur_de_monde/Tete/devoreur_de_monde_Head_Right.png",
                *DM_T_left= "image/devoreur_de_monde/Tete/devoreur_de_monde_Head_Left.png",
                *DM_T_down= "image/devoreur_de_monde/Tete/devoreur_de_monde_Head_Down.png",

                *DM_C_up= "image/devoreur_de_monde/Corp/devoreur_de_monde_Corp_UP.png", 
                *DM_C_right= "image/devoreur_de_monde/Corp/devoreur_de_monde_Corp_Right.png",
                *DM_C_left= "image/devoreur_de_monde/Corp/devoreur_de_monde_Corp_Left.png",
                *DM_C_down= "image/devoreur_de_monde/Corp/devoreur_de_monde_Corp_Down.png",

                *DM_Q_up= "image/devoreur_de_monde/Queue/devoreur_de_monde_Queue_UP.png", 
                *DM_Q_right= "image/devoreur_de_monde/Queue/devoreur_de_monde_Queue_Right.png",
                *DM_Q_left= "image/devoreur_de_monde/Queue/devoreur_de_monde_Queue_Left.png",
                *DM_Q_down= "image/devoreur_de_monde/Queue/devoreur_de_monde_Queue_Down.png",


                *caisse = "image/pommes/caisse.png",
                *Terrarian = "image/pommes/Terrarian.png",
                *caillou = "image/rochers/rock.png",

                *background = "image/fond/Background.png";

    ApresQueue->x = GUIOFSET_X;
    ApresQueue->y = GUIOFSET_Y;
    
    /* on met a 0 TIMER */
    TIMER->sec = 0;
    TIMER->min = 0;
    TIMER->heur = 0;

    /* et score */
    score->un = 0;
    score->di = 0;
    score->cen = 0;
    score->mil = 0;
    score->milon = 0;

    /* on initialise l'écrant */
    InitialiseEcran();
    AfficheBackground(background);
    ChoisirEcran(1);
    ChargerImageFond(background);
    ChoisirEcran(0);

    skin = Texturing(); /* sélectionne le skin */
    
    if(skin == 1 ){  /* on charges les sprites du train pour la tete, le corp, la queue et la pomme */
        tete->up = ChargerSprite(loco_back);
        tete->right = ChargerSprite(loco_right);
        tete->down = ChargerSprite(loco_front);
        tete->left = ChargerSprite(loco_left);

        corp->up = ChargerSprite(wagon_top);
        corp->right = ChargerSprite(wagon_cotes);
        corp->down = corp->up;
        corp->left = corp->right;

        queue->up = ChargerSprite(wagon_top);
        queue->right = ChargerSprite(wagon_cotes);
        queue->down = queue->up;
        queue->left = queue->right;

        SPomme = ChargerSprite(caisse);

    }else if(skin == 2 ){    /* on charges les sprites du Dévoreur de mondes pour la tete, le corp, la queue et la pomme */
        tete->up = ChargerSprite(DM_T_up);
        tete->right = ChargerSprite(DM_T_right);
        tete->down = ChargerSprite(DM_T_down);
        tete->left = ChargerSprite(DM_T_left);

        corp->up = ChargerSprite(DM_C_up);
        corp->right = ChargerSprite(DM_C_right);
        corp->down = ChargerSprite(DM_C_down);
        corp->left = ChargerSprite(DM_C_left);

        queue->up = ChargerSprite(DM_Q_up);
        queue->right = ChargerSprite(DM_Q_right);
        queue->down = ChargerSprite(DM_Q_down);
        queue->left = ChargerSprite(DM_Q_left);

        SPomme = ChargerSprite(Terrarian);
    }

    mode = Mode(); /* sélectionne le mode de jeu */

    SRock = ChargerSprite(caillou);

    if (mode == 1){
        printf("\n");
        TabRock = NULL;
        TabRock = InitRock(serpent);
    }else{ 
        if(mode == 0){
            TabRock = (Rock*)malloc(sizeof(Rock));
            TabRock->next = NULL;
            TabRock->x = 1000;
            TabRock->y = 1000;
        }
    }
    AfficherSnake(serpent, ApresQueue,tete,corp,queue);
    AffichePomme(TabPommes,SPomme);
    AfficheScore(score);
    AfficheRock(TabRock,SRock);
    
    while (end == IN) {  /* boucle infinit principale */
        if(Microsecondes() >= CYCLE+suivant){
            suivant = Microsecondes()+CYCLE;
            if (mode == 1){
                AfficheRock(TabRock,SRock);
            }

            if (ToucheEnAttente()){
                
                key = Touche();
                switch (key){

                case XK_Escape : /* Sortir de la boucle principale si la touche Escape est presser */
                    end = OUT;
                    break;  
                
                case XK_space : /* metre sur pause si la touche Escape est presser */
                    CopierZone(0, 2, GUIOFSET_X, GUIOFSET_Y, L, H, 0, 0); /* on copie tout l'écrant 0 dans le 1 */
                    ChoisirCouleurDessin(CouleurParNom("black"));  
                    RemplirRectangle(300, 170, 400, 300);
                    ChoisirCouleurDessin(CouleurParNom("white"));                           /* GUI du menu pause */
                    EcrireTexte(((L)/2)-(TailleChaineEcran("PAUSE",2)/2),220,"PAUSE",2);
                    EcrireTexte(325,300," <Space> - reprendre le jeu",1);
                    EcrireTexte(325,350," <Ecsape> - arret du jeu",1);
                    do{
                        key = Touche();
                        if (key == XK_Escape){
                            end = OUT;
                        }
                    } while ((key != XK_space) && end == IN);
                    CopierZone(2, 0, 0, 0, L, H, GUIOFSET_X, GUIOFSET_Y);   /* on copie l'écrant 1 dans le 0 */
                    break; 

                    /* on regarde si la touche enfoncer est une touche de déplacement */
                        /* et on évite de laisser le serpent aller dans a dirrection opposé a la sienne */

                case XK_Up: /* pour aller en haut */
                    if (serpent->direction != DOWN){
                        serpent->direction = UP;
                    }
                    break;

                case XK_Down: /* pour aller en bas */
                    if (serpent->direction != UP){
                        serpent->direction = DOWN;
                    }
                    break;
                
                case XK_Right: /* pour aller a droite */
                    if (serpent->direction != LEFT){
                        serpent->direction = RIGHT;
                    }
                    break;
                
                case XK_Left: /* pour aller a gauche */
                    if (serpent->direction != RIGHT){
                        serpent->direction = LEFT;
                    }
                    break;
                

                default:
                    break;
                }
            }
            DeplacerSnake(serpent, ApresQueue);

            if (NextSec == (SECONDS/CYCLE)/2){ /* la série de if pour que le temps s'incrémente bien */
                NextSec = 0;
                TIMER->sec++;
                if (TIMER->sec == 60){
                    TIMER->sec = 0;
                    TIMER->min++;
                    if (TIMER->min == 60){
                        TIMER->min = 0;
                        TIMER->heur++;
                    }
                }
            }
            NextSec++;

            Ahead = CheckAhead(serpent, TabPommes, TabRock, ApresQueue, tete, corp, queue, score, SPomme, SRock);   /* Check pour voir si on reste ou quite la boucle */
            if (Ahead == OUT){                                                                      /* selon si on rencontre un mur/son propre corp ou une pomme/rien */
                end = OUT;
            }   
            if (Ahead == IN){
                AfficheTime(TIMER);
                AfficherSnake(serpent, ApresQueue, tete, corp, queue); 
            }
        }
    }
/* on libèrre toute la mémoire de ce que l'on peut et évité les fuites de mémoires */

    LibererSpriteAll(tete, corp, queue);
    
    /* Permet de libérer toute l'espace alouer par malloc() et réalloc() au snake */
    
    for(Ssuiv=serpent->next; serpent->next == NULL; Ssuiv=serpent->next){
        free(serpent);
        serpent = Ssuiv;
    }
    free(serpent);
    
    free(ApresQueue);

    /* Permet de libérer toute l'espace alouer par malloc() aux pommes */

    for(Psuiv=TabPommes->next; TabPommes->next == NULL; Psuiv=TabPommes->next){
        free(TabPommes);
        TabPommes = Psuiv;
    }
    free(TabPommes);

    /* Permet de libérer toute l'espace alouer par malloc() aux pommes */
    
    if(TabRock == NULL){
        for(Rsuiv=TabRock->next; TabRock->next == NULL; Rsuiv=TabRock->next){
            free(TabRock);
            TabRock = Rsuiv;
        }
        free(TabRock);
    }

    LibererSprite(SRock);
    LibererSprite(SPomme); 
    FermerGraphique();
    exit;

    return EXIT_SUCCESS;
}