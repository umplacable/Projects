
#ifndef INIT_H
#define INIT_H

/* On define les directions de déplacement du serpent */
#define UP 0 
#define RIGHT 1 
#define DOWN 2
#define LEFT 3 

/* On define les réponces de certianes fonctions: */
    /* EstOcuper */
    #define YA_RIEN 0
    #define UN_MUR 1
    #define MA_QUEUE 2
    #define UNE_POMME 3
    #define A_ROCK 2

    /* pour rester et sortire de la boucle du main */
    #define IN 1
    #define OUT 0

#define ROCKS 50
#define POMMES 5
#define S_TAILLE 10
#define CYCLE 100000L
#define SECONDS 1000000L

/* Les valeurs de X et Y ou il y a un GUI*/
#define GUIOFSET_DOWN 20
#define GUIOFSET_X 20
#define GUIOFSET_X2 GUIOFSET_X+960
#define GUIOFSET_Y 20
#define GUIOFSET_Y2 GUIOFSET_Y+640
#define L 960+(2*GUIOFSET_X)
#define H 640+(2*GUIOFSET_Y)+GUIOFSET_DOWN

typedef char* FilePath;

struct Snake{       /* structure du snake */
    unsigned x;
    unsigned y;
    int direction;
    struct Snake* next;
};
typedef struct Snake Snake;

struct SnakeEnd{    /* structure de la fin du snake */
    unsigned x;
    unsigned y;
};
typedef struct SnakeEnd SnakeEnd;

struct Pomme{       /* structure de la pomme */
    unsigned x;
    unsigned y;
    struct Pomme *next;
};
typedef struct Pomme Pomme;

struct Rock{
    unsigned x;
    unsigned y;
    struct Rock *next;
};
typedef struct Rock Rock;

struct Texture{     /* structure des textures du snake */
    int up;
    int right;
    int down;
    int left;
};
typedef struct Texture Texture;

struct Timer_S{     /* structure du temp */
    int sec;
    int min;
    int heur;
};
typedef struct Timer_S Timer_S;

struct Score{       /* structure du Score */
    short un;
    short di;
    short cen;
    short mil;
    short milon;
};
typedef struct Score Score;

/* initialise l'écrant avec une taille deffinie */
void InitialiseEcran(void);

/* innitialtse le serpent en long au centre du plateau de jeu */
Snake* InitialiseSnake(void);

/* regarde si la coordonné (x,y) est occupé: une pomme, le bord du terrain, sa propre queue (, un mur si mode de jeux avec)*/
int EstOccuper(int x, int y, Snake *Serpent, Pomme *pomme, Rock *rock);

/* génère toute les pommes (début de partie) */
Pomme* InitPomme(Snake* serpent);
Rock* InitRock(Snake* serpent);
#endif