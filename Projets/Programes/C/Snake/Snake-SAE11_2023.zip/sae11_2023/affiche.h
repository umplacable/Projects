
#ifndef AFFICHE_H
#define AFFICHE_H

#include"init.h"

#define CYCLE 100000L

/* affiche le background */
void AfficheBackground(FilePath path);

/* affiche le serpent (la queue doit être les textures d'un wagon si c'est le skin du train)*/
void AfficherSnake(Snake* Serpent, SnakeEnd* ApresQueue, Texture *ImgTete, Texture *ImgCorp, Texture *ImgQueue);

void ModifsDansSnake(Snake* Serpent, SnakeEnd* ApresQueue);

int CheckAhead(Snake *Serpent, Pomme *pommes, Rock *rocks, SnakeEnd *ApresQueue, Texture *tete, Texture *corp, Texture *queue, Score *score, int SPomme,int SRock);
/* déplace le serpent */
void DeplacerSnake(Snake* Serpent, SnakeEnd* ApresQueue);

void AfficheRock(Rock* rocks, int sprite_rock);
/* affiche les pommes sur le plateau */
void AffichePomme(Pomme* pommes, int sprite_pommes);
/* génère une pome en remplacement de celle manger */
void RemplacerPomme(Snake* Serpent, Pomme* TabPommes,Rock* TabRocks,int SPomme, int SRock, unsigned x, unsigned y);

/* affiche le timer heur:minute:secondes */
void AfficheTime(Timer_S *TIMER);

/* affiche le score */
void AfficheScore(Score* score);

#endif
