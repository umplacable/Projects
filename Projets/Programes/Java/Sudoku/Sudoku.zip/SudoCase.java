import javax.swing.*;

import java.awt.event.*;

import java.awt.*;

public class SudoCase extends JComponent {

    protected SudoGrille grid;

    protected int SposI;
    protected int SposJ;
    protected int[] valeurs;
    public boolean isClicked = false;

    private Color AliceBlue = new Color(230, 241, 255);
    private int offsetX = -5;
    private int offsetY = 7;

    protected Color c1 = Color.black;

    @Override
    protected void paintComponent(Graphics pinceau) {
        // obligatoire : on crée un nouveau pinceau pour pouvoir le modifier plus tard
        Graphics secondPinceau = pinceau.create();
        Font curentFont = secondPinceau.getFont().deriveFont(secondPinceau.getFont().getSize() * 1.5F);
        Font newFont = secondPinceau.getFont().deriveFont(secondPinceau.getFont().getSize() * 2F);
        secondPinceau.setFont(curentFont);
        // obligatoire : si le composant n'est pas censé être transparent
        if (this.isOpaque()) {
            // obligatoire : on repeint toute la surface avec la couleur de fond
            secondPinceau.setColor(this.AliceBlue);
            secondPinceau.fillRect(0, 0, this.getWidth(), this.getHeight());
        }
        // maintenant on dessine ce que l'on veut
        if (isClicked) {
            secondPinceau.setColor(this.AliceBlue);
            secondPinceau.fillRect(0, 0, this.getWidth(), this.getHeight());
        } else {
            secondPinceau.setColor(Color.white);
            secondPinceau.fillRect(0, 0, this.getWidth(), this.getHeight());
        }
        secondPinceau.setColor(c1);

        int compteNombre = 0;
        int[] ID = new int[4];
        int k = 0;
        for (int i = 0; i < this.valeurs.length; i++) {
            if (this.valeurs[i] != 0) {
                compteNombre++;
                ID[k] = i;
                k++;
            }
        }
        if (compteNombre == 1) {
            secondPinceau.setFont(newFont);
            secondPinceau.drawString(String.valueOf(this.valeurs[ID[0]]), (this.getWidth() / 2) + offsetX,
                    (this.getHeight() / 2) + offsetY + 3);
        } else if (compteNombre == 2) {
            secondPinceau.drawString(String.valueOf(this.valeurs[ID[0]]), (this.getWidth() / 4) + offsetX,
                    (this.getHeight() / 2) + offsetY);
            secondPinceau.drawString(String.valueOf(this.valeurs[ID[1]]), ((this.getWidth() * 3) / 4) + offsetX,
                    (this.getHeight() / 2) + offsetY);
        } else if (compteNombre == 3) {
            secondPinceau.drawString(String.valueOf(this.valeurs[ID[0]]), (this.getWidth() / 4) + offsetX,
                    (this.getHeight() / 4) + offsetY);
            secondPinceau.drawString(String.valueOf(this.valeurs[ID[1]]), ((this.getWidth() * 3) / 4) + offsetX,
                    (this.getHeight() / 4) + offsetY);
            secondPinceau.drawString(String.valueOf(this.valeurs[ID[2]]), (this.getWidth() / 4) + offsetX,
                    ((this.getHeight() * 3) / 4) + offsetY);
        } else if (compteNombre == 4) {
            secondPinceau.drawString(String.valueOf(this.valeurs[0]), (this.getWidth() / 4) + offsetX,
                    (this.getHeight() / 4) + offsetY);
            secondPinceau.drawString(String.valueOf(this.valeurs[1]), ((this.getWidth() * 3) / 4) + offsetX,
                    (this.getHeight() / 4) + offsetY);
            secondPinceau.drawString(String.valueOf(this.valeurs[2]), (this.getWidth() / 4) + offsetX,
                    ((this.getHeight() * 3) / 4) + offsetY);
            secondPinceau.drawString(String.valueOf(this.valeurs[3]), ((this.getWidth() * 3) / 4) + offsetX,
                    ((this.getHeight() * 3) / 4) + offsetY);
        }

    }

    public SudoCase(int i, int j, SudoGrille grille) {
        /** constructeur */

        this.setBorder(BorderFactory.createLineBorder(Color.black, 1));

        this.SposI = i;
        this.SposJ = j;
        this.grid = grille;
        this.valeurs = new int[4];
    }

    public int getI() {
        /** pour obtenir SposI */
        return this.SposI;
    }

    public int getJ() {
        /** pour obtenir SposJ */
        return this.SposJ;
    }

    public int[] getValues() {
        /** pour obtenir le tableau de valeurs */
        return this.valeurs;
    }

    protected void integrityCheck() {
        /** appelle Intégrity check */
        this.grid.textUpdate(SposI, SposJ);
    }

    public void textChanged(KeyEvent e) {
    }

    public int getNbValues() {
        /** pour obtenir le nombres de valeurs */
        int n = 0;
        for (int i : this.valeurs) {
            if (i != 0) {
                n++;
            }
        }
        return n;
    }

    public void setCaseValues(int val) {
        /** pour set le nombres de valeurs */
        this.valeurs[0] = val;
        for (int i = 1; i < this.valeurs.length; i++) {
            this.valeurs[i] = 0;
        }
        this.repaint();
    }

    public void reset() {
        /** pour set les valeurs */
        this.setCaseValues(0);
    }
}