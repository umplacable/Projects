import java.awt.*;
import java.io.*;

import javax.swing.*;

public class SudoGrille extends JPanel {

    public SudoFrame SFrame;
    private SudoJPanel[][] grid;

    public SudoGrille(File file, SudoFrame f) {
        /** Constructeur */

        try {
            FileInputStream fr = new FileInputStream(file);
            DataInputStream data = new DataInputStream(fr);

            this.grid = new SudoJPanel[9][9];
            this.SFrame = f;

            this.setLayout(new GridLayout(9, 9));

            /*
             * on lit les valeurs dans le fichier tout en les traitant, puis on génère les
             * cases a partir de ses valeurs
             */
            for (int i = 0; i < 9; i++) {
                try {
                    int line = data.readInt();
                    int val = 0;
                    for (int j = 8; j >= 0; j--) {
                        val = line % 10;
                        line = (line - val) / 10;
                        if (val != 0) {
                            this.grid[i][j] = new SudoJPanel(new SudoCasePleine(i, j, val, this));
                            val = 0;
                        } else {
                            this.grid[i][j] = new SudoJPanel(new SudoCaseVide(i, j, this));
                            val = 0;
                        }
                    }
                } catch (IOException e) {
                    System.err.println("érreur lors de la lecture dans le fichier");
                }
            }
            try {
                data.close();
            } catch (IOException e) {
                System.err.println("érreur lors de la fermeture du fichier");
            }

            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 9; j++) {
                    this.add(this.grid[i][j]);
                }
            }

        } catch (FileNotFoundException e) {
            System.err.println("Fichier non trouver, FileNotFoundException");
        } catch (NullPointerException e) {
            System.err.println("Aucun fichier n'a été sélectionner, NullPointerException");
        }

    }

    public SudoGrille(SudoFrame f) {
        /** Constructeur pour des case vides */

        this.grid = new SudoJPanel[9][9];
        this.SFrame = f;
        this.setBackground(Color.BLACK);

        this.setSize(900, 900);

        this.setLayout(new GridLayout(9, 9));

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                this.grid[i][j] = new SudoJPanel(new SudoCaseVide(i, j, this));
            }
        }

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                this.add(this.grid[i][j]);
            }
        }
    }

    public SudoGrille(SudoFrame f, File file, int id) {
        /** Constructeur pour la résolution automatique */

        if (id == 4472) {
            this.grid = new SudoJPanel[9][9];
            this.SFrame = f;
            this.setBackground(Color.BLACK);

            this.setSize(900, 900);

            this.setLayout(new GridLayout(9, 9));
            try {
                FileInputStream fr = new FileInputStream(file);
                DataInputStream data = new DataInputStream(fr);

                int[][] valeurs = new int[9][9];

                /*
                 * on lit les valeurs dans le fichier tout en les traitant, puis on les met dans
                 * un tableau de valeurs
                 */
                for (int i = 0; i < 9; i++) {
                    try {
                        int line = data.readInt();
                        int val = 0;
                        for (int j = 8; j >= 0; j--) {
                            val = line % 10;
                            line = (line - val) / 10;
                            if (val != 0) {
                                valeurs[i][j] = val;
                                val = 0;
                            } else {
                                valeurs[i][j] = 0;
                                val = 0;
                            }
                        }
                    } catch (IOException e) {
                        System.err.println("érreur lors de la lecture dans le fichier");
                    }
                }

                this.automatique(valeurs);

                try {
                    data.close();
                } catch (IOException e) {
                    System.err.println("érreur lors de la fermeture du fichier");
                }

            } catch (FileNotFoundException e) {
                System.err.println("Fichier non trouver, FileNotFoundException");
            } catch (NullPointerException e) {
                e.printStackTrace();
                System.err.println("Aucun fichier n'a été sélectionner, NullPointerException");
            }
        } else {
            System.err.println(
                    "vous ne pouvez pas utilisé ce constructeur, celui-ci ne doit etre utilisé que pour la résolution automatique!");
        }

    }

    private void doGrille(int[][] valeurs) {
        /** méthode pour faire la grille après résolution automatique */
        for (int i = 0; i < valeurs.length; i++) {
            for (int j = 0; j < valeurs.length; j++) {
                this.grid[i][j] = new SudoJPanel(new SudoCasePleine(i, j, valeurs[i][j], this));
                this.add(this.grid[i][j]);
            }
        }
    }

    private void automatique(int[][] valeurs) throws IllegalArgumentException {
        /** méthode en mode automatique */

        long startTime = System.nanoTime();

        boolean solved = solveSudoku(0, 0, valeurs);

        long endTime = System.nanoTime();
        double duration = (endTime - startTime) / 1000;

        if (solved) {
            this.SFrame.warningMesage("Sudoku solved in " + duration + " microsecondes.");
            this.doGrille(valeurs);
        } else {
            System.err.println("No solution found.");
            System.exit(1);
        }
    }

    private boolean solveSudoku(int row, int col, int[][] board) {
        /** méthode de résulution en mode automatique par récurcivité */

        if (row == 9) { // si c a la fin de la der colonne ca s'arrete
            return true;
        }

        int nextRow = col == 8 ? row + 1 : row;
        int nextCol = col == 8 ? 0 : col + 1;

        if (board[row][col] != 0) { // on skip les cell avec une valeur != 0
            return solveSudoku(nextRow, nextCol, board);
        }

        for (int num = 1; num <= 9; num++) { // on skip les cell avec une valeur != 0
            board[row][col] = num;
            if (isIntegrityOK(row, col, board)) {
                if (solveSudoku(nextRow, nextCol, board)) {
                    return true;
                }
            } else {
                board[row][col] = 0;
            }
        }
        return false;
    }

    private boolean isIntegrityOK(int x, int y) throws IllegalArgumentException {
        /** on check les inchoérence dans la grille */

        int[][][] tab = this.getGridValues();

        /*
         * on teste sur toute une ligne de la grille, voir si les valeurs de la case
         * correspondent a l'intégrité
         */
        for (int i = 0; i < 9; i++) {
            if (i != x) {
                if ((tab[i][y][0] == tab[x][y][0]) & (tab[x][y][0] != 0)) {
                    throw new IllegalArgumentException("La valeur fournise n'est pas valide 1");
                }
            }
        }

        /*
         * on teste sur toute une collone de la grille, voir si les valeurs de la case
         * correspondents a l'intégrité
         */
        for (int i = 0; i < 9; i++) {
            if (i != y) {
                if ((tab[x][i][0] == tab[x][y][0]) & (tab[x][y][0] != 0)) {
                    throw new IllegalArgumentException("La valeur fournise n'est pas valide 2");
                }
            }
        }

        /*
         * on teste sur tout un groupement de la grille, voir si les valeurs de la case
         * correspondents a l'intégrité
         */

        int groupementX = x % 3;
        int groupementY = y % 3;

        if (x < 3) {
            groupementX = 0;
        } else if (x < 6) {
            groupementX = 1;
        } else if (x < 9) {
            groupementX = 2;
        }

        if (y < 3) {
            groupementY = 0;
        } else if (y < 6) {
            groupementY = 1;
        } else if (y < 9) {
            groupementY = 2;
        }

        for (int i = 0; i < 3; i++) {
            int n = i + 3 * groupementX;
            for (int k = 0; k < 3; k++) {
                int m = k + 3 * groupementY;
                if (!(n == x & m == y)) {
                    if ((tab[n][m][0] == tab[x][y][0]) & (tab[x][y][0] != 0)) {
                        throw new IllegalArgumentException("La valeur fournise n'est pas valide 3");
                    }
                }
            }
        }
        return true;
    }

    private boolean isIntegrityOK(int x, int y, int[][] tab) {
        /**
         * on check les inchoérence dans la grille (méthode pour lea résolution
         * automatique)
         */

        /*
         * on teste sur toute une ligne de la grille, voir si les valeurs de la case
         * correspondent a l'intégrité
         */
        for (int i = 0; i < 9; i++) {
            if (i != x) {
                if ((tab[i][y] == tab[x][y]) & (tab[x][y] != 0)) {
                    return false;
                }
            }
        }

        /*
         * on teste sur toute une collone de la grille, voir si les valeurs de la case
         * correspondents a l'intégrité
         */
        for (int i = 0; i < 9; i++) {
            if (i != y) {
                if ((tab[x][i] == tab[x][y]) & (tab[x][y] != 0)) {
                    return false;
                }
            }
        }

        /*
         * on teste sur tout un groupement de la grille, voir si les valeurs de la case
         * correspondents a l'intégrité
         */

        int groupementX = x % 3;
        int groupementY = y % 3;

        if (x < 3) {
            groupementX = 0;
        } else if (x < 6) {
            groupementX = 1;
        } else if (x < 9) {
            groupementX = 2;
        }

        if (y < 3) {
            groupementY = 0;
        } else if (y < 6) {
            groupementY = 1;
        } else if (y < 9) {
            groupementY = 2;
        }

        for (int i = 0; i < 3; i++) {
            int n = i + 3 * groupementX;
            for (int k = 0; k < 3; k++) {
                int m = k + 3 * groupementY;
                if (!(n == x & m == y)) {
                    if ((tab[n][m] == tab[x][y]) & (tab[x][y] != 0)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public boolean isFinised() {
        /** méthode sevant a savoir si la grille est finit */

        for (SudoJPanel[] sudoJPanels : this.grid) {
            for (SudoJPanel panel : sudoJPanels) {
                SudoCase C = panel.Case;
                if (C.getNbValues() == 1) {
                    if (C.getValues()[0] != 0) {
                        try {
                            this.isIntegrityOK(C.getI(), C.getJ());
                        } catch (IllegalArgumentException e) {
                            return false;
                        }
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            }
        }
        return true;
    }

    public int[][][] getGridValues() {
        /** méthode d'extraction des valeurs de la grille */
        int[][][] tab = new int[9][9][4];

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (this.grid[i][j].Case.getNbValues() == 1) {
                    tab[i][j] = this.grid[i][j].Case.getValues();
                }
            }
        }
        return tab;
    }

    public void factoryReset() {
        /** reset de la valeur des cases (pour la création) */
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[i].length; j++) {
                this.grid[i][j].Case.reset();
                this.grid[i][j].Case.repaint();
            }
        }
    }

    public void redoGrid(File file) {
        /** méthode pour refaire la grille avec de nouvelles valeurs */

        try {
            FileInputStream fr = new FileInputStream(file);
            DataInputStream data = new DataInputStream(fr);

            for (int i = 0; i < 9; i++) {
                try {
                    if (data.available() > 0) {
                        try {
                            int line = data.readInt();
                            int val = 0;
                            for (int j = 8; j >= 0; j--) {
                                val = line % 10;
                                line = (line - val) / 10;
                                if (val != 0) {
                                    this.grid[i][j].Case.setCaseValues(val);
                                    this.grid[i][j].Case.repaint();
                                    val = 0;
                                } else {
                                    this.grid[i][j].Case.reset();
                                    ;
                                    this.grid[i][j].Case.repaint();
                                    val = 0;
                                }
                            }
                        } catch (IOException e) {
                            System.err.println("érreur lors de la lecture dans le fichier");
                        }
                    }
                } catch (IOException e) {
                    System.err.println("érreur lors de la lecture dans le fichier");
                }
            }
            try {
                data.close();
            } catch (IOException e) {
                System.err.println("érreur lors de la fermeture du fichier");
            }

        } catch (FileNotFoundException e) {
            System.err.println("érreur dans l'ouverture du fichier, FileNotFoundException");
        } catch (NullPointerException e) {
            System.err.println("Aucun fichier n'a été sélectionner, NullPointerException");
        }
    }

    public void textUpdate(int x, int y) {
        /** méthodes apeller lors d'un changement dans les valeurs d'une case */

        try {
            this.isIntegrityOK(x, y);

            if (this.isFinised()) {
                this.SFrame.WinMesage("Bravo vous avez gagné, la grille est complète");
            }

        } catch (IllegalArgumentException e) {
            this.SFrame.warningMesage("en faisant sa l'intégrité n'est pas respecté" + e.getMessage());
            this.grid[x][y].Case.reset();
        }
    }

    public SudoCase getClickedCase() {
        /** pour connaitre quelle case à été clickée */

        for (SudoJPanel[] sudoJPanels : this.grid) {
            for (SudoJPanel panel : sudoJPanels) {
                if (panel.Case.isClicked) {
                    return panel.Case;
                }
            }
        }
        return null;
    }

    public void setClickedCase(int x, int y) {
        /** pour deffinir la case clickée */

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (!(x == i && y == j)) {
                    this.grid[i][j].Case.isClicked = false;
                    this.grid[i][j].Case.repaint();
                }
            }
        }
        this.grid[x][y].Case.isClicked = true;
        this.grid[x][y].Case.repaint();
    }
}