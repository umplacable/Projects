
public class ResoudreSudoku {

    public static void main(String[] args) {
        /** fonction main pour la résolution du sudoku */

        SudoFrame f = new SudoFrame(0x3D41FC);
        f.setVisible(true);
    }

}