# SAE21_2022

**Toutes les grilles de jeux devrons être stocker dans le dossier `./Grilles` pour nous faciliter la vie.**

Pour créer un sudoku, lancez la commande `make creer`.

Pour jouer à un sudoku, lancez la commande `make jouer`.