
public class SudoCasePleine extends SudoCase {

    public SudoCasePleine(int i, int j, int valeur, SudoGrille grille) {
        /** Constructeur */

        super(i, j, grille);

        this.valeurs[0] = valeur;
    }
}