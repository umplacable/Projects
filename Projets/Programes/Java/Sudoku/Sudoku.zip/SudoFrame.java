import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class SudoFrame extends JFrame implements ActionListener, KeyListener {

    private SudoGrille grille;

    private JButton buttonCharger;
    private JButton buttonSauvegarder;
    private JButton buttonResetGrid;

    private SudoPanel SPButtons;
    private SudoWarn Warning;

    public SudoFrame(int Discriminant) {
        /** Constructeur */

        this.setSize(750, 750);
        this.setLocation(100, 100);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.addKeyListener(this);
        this.setFocusable(true);
        this.requestFocus(true);
        this.Warning = new SudoWarn();
        this.add(this.Warning, BorderLayout.SOUTH);

        if (Discriminant == 0xEC372E) { // pour le programe de création
            this.SPButtons = new SudoPanel();

            this.buttonCharger = new JButton("Charger grille");
            this.buttonCharger.addActionListener(this);
            this.SPButtons.add(this.buttonCharger);

            this.buttonResetGrid = new JButton("Vider grille");
            this.buttonResetGrid.addActionListener(this);
            this.SPButtons.add(this.buttonResetGrid);

            this.buttonSauvegarder = new JButton("Sauvegarder grille");
            this.buttonSauvegarder.addActionListener(this);
            this.SPButtons.add(this.buttonSauvegarder);

            this.add(this.SPButtons, BorderLayout.NORTH);

            this.grille = new SudoGrille(this);

            this.add(this.grille, BorderLayout.CENTER);
        } else if (Discriminant == 0x3D41FC) { // pour le programe de résolution
            this.resolution();
        }
    }

    protected void remakeTheGrid() {
        /** pour refaire la grille */

        JFileChooser fChoose = new JFileChooser("./Grilles");

        fChoose.setDialogTitle("choisisez le sudoku a faire");
        fChoose.setFileSelectionMode(JFileChooser.FILES_ONLY);

        try {
            int ret = fChoose.showOpenDialog(null);
            switch (ret) {
                case JFileChooser.CANCEL_OPTION:
                    System.err.println("vous avez annuler le choix");
                    System.exit(1);
                    break;

                case JFileChooser.ERROR_OPTION:
                    System.err.println("vous avez fermer la fenetre");
                    System.exit(1);
                    break;

                case JFileChooser.APPROVE_OPTION:
                    break;

                default:
                    System.err.println("Il y a ue un probleme inconnue avec la fenetre de choix de fichier");
                    System.exit(1);
                    break;
            }

            grille.redoGrid(fChoose.getSelectedFile());

        } catch (HeadlessException e) {
            System.err.println("érreur lors du choix de fichier sans queue ni tête, HeadlessException");
        }
    }

    public void resolution() {
        /** pour résoudre le sudoku */

        JFileChooser fChoose = new JFileChooser("./Grilles");

        fChoose.setDialogTitle("choisisez le sudoku a faire");
        fChoose.setFileSelectionMode(JFileChooser.FILES_ONLY);

        try {
            int ret = fChoose.showOpenDialog(null);
            switch (ret) {
                case JFileChooser.CANCEL_OPTION:
                    System.err.println("vous avez annuler le choix");
                    System.exit(1);
                    break;

                case JFileChooser.ERROR_OPTION:
                    System.err.println("vous avez fermer la fenetre");
                    System.exit(1);
                    break;

                case JFileChooser.APPROVE_OPTION:
                    break;

                default:
                    System.err.println("Il y a ue un probleme inconnue avec la fenetre de choix de fichier");
                    System.exit(1);
                    break;
            }

            Object[] choix = { "Manuel", "Automatique" };

            try {
                int reponse = JOptionPane.showOptionDialog(null,
                        "comment sera la résolution du Sudoku ?",
                        " ",
                        JOptionPane.DEFAULT_OPTION,
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        choix,
                        null);

                if (reponse == 1) { // Résolution automatique
                    this.grille = new SudoGrille(this, fChoose.getSelectedFile(), 4472);
                } else if (reponse == 0) { // Résolution manuel
                    this.grille = new SudoGrille(fChoose.getSelectedFile(), this);
                } else {
                    System.err.println("vous avez annuler le choix");
                    System.exit(1);
                }
                this.add(grille, BorderLayout.CENTER);
            } catch (HeadlessException e) {
                System.err.println("érreur lors du choix de réponce sans queue ni tête, HeadlessException");

            }
        } catch (HeadlessException e) {
            System.err.println("érreur lors du choix de fichier sans queue ni tête, HeadlessException");
        }
    }

    protected void save() {
        /** pour sauvegarder */
        JFileChooser fSave = new JFileChooser("./Grilles");

        fSave.setDialogTitle("choisisez un fichier de sauvegarde");
        fSave.setFileSelectionMode(JFileChooser.FILES_ONLY);
        try {
            int ret = fSave.showSaveDialog(null);
            switch (ret) {
                case JFileChooser.CANCEL_OPTION:
                    System.err.println("vous avez annuler le choix");
                    break;

                case JFileChooser.ERROR_OPTION:
                    System.err.println("vous avez fermer la fenetre");
                    break;

                case JFileChooser.APPROVE_OPTION:
                    break;

                default:
                    System.err.println("Il y a ue un probleme inconnue avec la fenetre de choix de fichier");
                    System.exit(1);
                    break;
            }
        } catch (HeadlessException e) {
            System.err.println("érreur lors du choix de fichier sans queue ni tête, HeadlessException");
        }
        try {
            FileOutputStream fw = new FileOutputStream(fSave.getSelectedFile());
            DataOutputStream data = new DataOutputStream(fw);

            int[][][] valeurs = this.grille.getGridValues();

            for (int i = 0; i < 9; i++) {
                int buff = 0;
                int mult = 1;
                for (int j = 8; j >= 0; j--) {
                    buff += valeurs[i][j][0] * mult;
                    mult *= 10;
                }
                try {
                    data.writeInt(buff);
                } catch (IOException e) {
                    System.err.println("Impossible d'écrire dans le fichier");
                }
            }
            try {
                data.close();
            } catch (IOException e) {
                System.err.println("imposssible de fermer le fichier");
            }
        } catch (FileNotFoundException e) {
            System.err.println("Fichier non trouver, FileNotFoundException");
        } catch (NullPointerException e) {
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        /** s'active lors de l'appuit sur un boutton */
        if (e.getSource() == this.buttonCharger) {
            this.remakeTheGrid();
        } else if (e.getSource() == this.buttonSauvegarder) {
            this.save();
        } else if (e.getSource() == this.buttonResetGrid) {
            this.grille.factoryReset();
        }
        this.requestFocus();
    }

    public void warningMesage(String message) {
        /** message d'avertissement */
        this.Warning.warningMesage(message);
    }

    public void WinMesage(String message) {
        /** message normale / victiore */
        this.Warning.WinMesage(message);
    }

    @Override
    public void keyPressed(KeyEvent e) {
        /** s'active lors de l'appuit sur une touche du clavier */
        int i = 0;
        int j = 0;
        SudoCase C = this.grille.getClickedCase();
        if (C != null) {
            i = C.getI();
            j = C.getJ();
        }
        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP:
                if (i > 0) {
                    this.grille.setClickedCase(--i, j);
                }
                break;
            case KeyEvent.VK_DOWN:
                if (i < 8) {
                    this.grille.setClickedCase(++i, j);
                }
                break;
            case KeyEvent.VK_LEFT:
                if (j > 0) {
                    this.grille.setClickedCase(i, --j);
                }
                break;
            case KeyEvent.VK_RIGHT:
                if (j < 8) {
                    this.grille.setClickedCase(i, ++j);
                }
                break;

            default:
                break;
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
        /** s'active lors de l'appuit sur une touche du clavier */
        SudoCase C = this.grille.getClickedCase();
        if (C != null) {
            C.textChanged(e);
        }
    }
}