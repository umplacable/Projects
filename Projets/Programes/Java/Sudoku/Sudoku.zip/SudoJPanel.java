import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

public class SudoJPanel extends JPanel {
    public SudoCase Case;

    public SudoJPanel(SudoCase c) {
        /** Constructeur, créer pour contenir une case */
        super(new BorderLayout());

        this.setBackground(Color.BLACK);
        this.Case = c;

        this.add(this.Case);

        int top = 0;
        int bottom = 0;
        int left = 0;
        int right = 0;

        if (this.Case.getI() % 3 == 0) {
            top = 1;
        }
        if (this.Case.getJ() % 3 == 0) {
            left = 1;
        }
        if (this.Case.getI() % 3 == 2) {
            bottom = 1;
        }
        if (this.Case.getJ() % 3 == 2) {
            right = 1;
        }
        this.setBorder(BorderFactory.createMatteBorder(top, left, bottom, right, Color.BLACK));
    }

}
