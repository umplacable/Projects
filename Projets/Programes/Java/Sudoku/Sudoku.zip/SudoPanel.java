import java.awt.FlowLayout;

import javax.swing.JPanel;

public class SudoPanel extends JPanel {
    public SudoPanel() {
        /** Constructeur, contiend soit les boutons soit les messages */
        super();
        this.setLayout(new FlowLayout());
    }
}
