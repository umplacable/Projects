import java.awt.Color;

import javax.swing.JLabel;

public class SudoWarn extends SudoPanel {

    private String text = "";

    private JLabel message;

    public SudoWarn() {
        /** Constructeur */
        super();
        this.message = new JLabel(text);

        this.add(message);
    }

    public void warningMesage(String t) {
        /** affiche un message d'éreur */
        this.text = t;
        this.message.setForeground(Color.RED);
        this.message.setText(text);
    }

    public void WinMesage(String t) {
        /** affiche un message */
        this.text = t;
        this.message.setForeground(Color.black);
        this.message.setText(text);
    }
}