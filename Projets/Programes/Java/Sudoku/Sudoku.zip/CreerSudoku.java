
public class CreerSudoku {

    public static void main(String[] args) {
        /** fonction main pour la fabrication du sudoku */

        SudoFrame frame = new SudoFrame(0xEC372E);
        frame.setVisible(true);
    }
}