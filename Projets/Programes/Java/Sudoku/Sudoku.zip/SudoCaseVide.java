import java.awt.Color;
import java.awt.event.*;

public class SudoCaseVide extends SudoCase implements MouseListener {

    public SudoCaseVide(int i, int j, SudoGrille grille) {
        /** Constructeur sans valeurs */

        super(i, j, grille);
        this.c1 = new Color(25, 25, 25);

        this.addMouseListener(this);
    }

    public SudoCaseVide(int i, int j, int val, SudoGrille grille) {
        /** Constructeur avec valeur */

        super(i, j, grille);

        this.c1 = new Color(25, 25, 25);

        this.valeurs = new int[4];
        this.valeurs[0] = val;

        this.addMouseListener(this);
    }

    public void textChanged(KeyEvent e) {
        /** méthode apellée lors d'un changement de texte */
        this.grid.SFrame.warningMesage("");
        if (this.isClicked) {

            /*
             * on regarde pour toutes les valeurs numériques de 1 à 9 ainsi que pour
             * la touche de retour
             */
            int key = e.getKeyChar();
            if (key == KeyEvent.VK_BACK_SPACE) { // touche de retour
                for (int i = this.valeurs.length - 1; i >= 0; i--) {
                    if (this.valeurs[i] != 0) {
                        this.valeurs[i] = 0;
                        break;
                    }
                }
            } else if (key == '1') { // 1
                for (int i = 0; i < this.valeurs.length; i++) {
                    if (this.valeurs[i] == 0) {
                        this.valeurs[i] = 1;
                        break;
                    } else if (i == 4 & this.valeurs[i] == 0) {
                        this.grid.SFrame.warningMesage("il y a trops de valeurs dans cette case");
                    }
                }
            } else if (key == '2') { // 2
                for (int i = 0; i < this.valeurs.length; i++) {
                    if (this.valeurs[i] == 0) {
                        this.valeurs[i] = 2;
                        break;
                    } else if (i == 4 & this.valeurs[i] == 0) {
                        this.grid.SFrame.warningMesage("il y a trops de valeurs dans cette case");
                    }
                }
            } else if (key == '3') { // 3
                for (int i = 0; i < this.valeurs.length; i++) {
                    if (this.valeurs[i] == 0) {
                        this.valeurs[i] = 3;
                        break;
                    } else if (i == 4 & this.valeurs[i] == 0) {
                        this.grid.SFrame.warningMesage("il y a trops de valeurs dans cette case");
                    }
                }
            } else if (key == '4') { // 4
                for (int i = 0; i < this.valeurs.length; i++) {
                    if (this.valeurs[i] == 0) {
                        this.valeurs[i] = 4;
                        break;
                    } else if (i == 4 & this.valeurs[i] == 0) {
                        this.grid.SFrame.warningMesage("il y a trops de valeurs dans cette case");
                    }
                }
            } else if (key == '5') { // 5
                for (int i = 0; i < this.valeurs.length; i++) {
                    if (this.valeurs[i] == 0) {
                        this.valeurs[i] = 5;
                        break;
                    } else if (i == 4 & this.valeurs[i] == 0) {
                        this.grid.SFrame.warningMesage("il y a trops de valeurs dans cette case");
                    }
                }
            } else if (key == '6') { // 6
                for (int i = 0; i < this.valeurs.length; i++) {
                    if (this.valeurs[i] == 0) {
                        this.valeurs[i] = 6;
                        break;
                    } else if (i == 4 & this.valeurs[i] == 0) {
                        this.grid.SFrame.warningMesage("il y a trops de valeurs dans cette case");
                    }
                }
            } else if (key == '7') { // 7
                for (int i = 0; i < this.valeurs.length; i++) {
                    if (this.valeurs[i] == 0) {
                        this.valeurs[i] = 7;
                        break;
                    } else if (i == 4 & this.valeurs[i] == 0) {
                        this.grid.SFrame.warningMesage("il y a trops de valeurs dans cette case");
                    }
                }
            } else if (key == '8') { // 8
                for (int i = 0; i < this.valeurs.length; i++) {
                    if (this.valeurs[i] == 0) {
                        this.valeurs[i] = 8;
                        break;
                    } else if (i == 4 & this.valeurs[i] == 0) {
                        this.grid.SFrame.warningMesage("il y a trops de valeurs dans cette case");
                    }
                }
            } else if (key == '9') { // 9
                for (int i = 0; i < this.valeurs.length; i++) {
                    if (this.valeurs[i] == 0) {
                        this.valeurs[i] = 9;
                        break;
                    } else if (i == 4 & this.valeurs[i] == 0) {
                        this.grid.SFrame.warningMesage("il y a trops de valeurs dans cette case");
                    }
                }
            } else {
                this.grid.SFrame.warningMesage("La valeur que vous tentez d'insérer n'est pas recunue.");
            }
            super.repaint();
            this.integrityCheck();

        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        /** fonction apeller quand la sourie clique sur la case */
        if (!isClicked) {
            this.isClicked = true;
            this.grid.setClickedCase(SposI, SposJ);
            super.repaint();
        } else {
            this.isClicked = false;
            super.repaint();
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }
}