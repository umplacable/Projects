    </main>
    <footer>
        <article>
            <nav style="flex-wrap: wrap; align-items:center;">
                <p>&copy; 2024 Spotifix. Tous droits réservés.</p>
                <?="<img src='".base_url("assets/spotifix_logo.png")."' alt='' width='4%'>"?>
            </nav>
        </article>
    </footer>
</body>
</html>