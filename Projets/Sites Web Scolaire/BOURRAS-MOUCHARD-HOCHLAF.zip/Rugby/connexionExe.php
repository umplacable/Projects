<?php
    date_default_timezone_set('UTC');

    if(     isset($_POST['mdp'])    && 
            isset($_POST['pseudo'])
    ){

        $pseudo = $_POST['pseudo'];
        $pass = $_POST['mdp'];

        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "rugby";
        // Create connection
        $conn = mysqli_connect($servername, $username, $password,$database);
        mysqli_set_charset($conn, "utf8");
        // Check connection
        if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
        }
        
        //echo "Connected successfully";
        $sql = "SELECT idInternaute FROM internaute WHERE int_pseudo = '$pseudo' and int_motPasse = '$pass'";
        $result = mysqli_query($conn, $sql);
        

        if (mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_assoc($result);

            echo " Connecté";
            setcookie('idUser', $row['idInternaute'], NULL , '/', '', false, false);
            header("location:index.php");
          
        } else {
            header("location:connexion.php?erreur=mot de pass ou pseudo incorrect");
          }
        }

        mysqli_close($conn);
        ?>