<?php
date_default_timezone_set('UTC');
    if(     isset($_POST['nom']) && 
            isset($_POST['prenom'])    && 
            isset($_POST['equipe']) && 
            isset($_POST['poste'])
    ){

        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $equipe = $_POST['equipe'];
        $position = $_POST['poste'];


        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "rugby";
        // Create connection
        $conn = mysqli_connect($servername, $username, $password,$database);
        mysqli_set_charset($conn, "utf8");
        // Check connection
        if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());

        }
        //echo "Connected successfully";
        $sqlequipe = "SELECT * FROM equipe WHERE '$equipe' = equ_nom";
        $resultsqlequipe = mysqli_query($conn, $sqlequipe);
        $idequipe = mysqli_fetch_assoc($resultsqlequipe);
        $idequ = $idequipe['idEquipe'];

        $sqlposition = "SELECT * FROM poste WHERE '$position' = pos_nom";
        $resultsqlposition = mysqli_query($conn ,$sqlposition);
        $idposition = mysqli_fetch_assoc($resultsqlposition);
        $idpos = $idposition['code'];

        $sql = "INSERT INTO `rugby`.`joueur` (`jou_nom`, `jou_prenom`, `jou_image`, `idEquipe`, `codePoste`) VALUES ('$nom', '$prenom', NULL, $idequ, $idpos)";

        if (mysqli_multi_query($conn, $sql)) {
            echo "New records created successfully";
            header("location:./afficherJoueurs.php");
          } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
          }
        
        } else {
            echo "<p>Toutes les données doivent être renseignées.</p>\n";
        }
    
?>
