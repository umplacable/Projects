---------------------------------------------------------
--Hôte : 127.0.0.1
--Version du serveur: 5.1.72-community - MySQL Community Server (GPL)
--SE du serveur: Win32
--HeidiSQL Version: 10.2.0.5599
----------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Listage de la structure de la base pour rugby

DROP DATABASE IF EXISTS `rugby`;
CREATE DATABASE IF NOT EXISTS `rugby` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `rugby`;
-- Listage de la structure de la table rugby. equipe
DROP TABLE IF EXISTS `equipe`;
CREATE TABLE IF NOT EXISTS `equipe` (
`idEquipe` int(11) NOT NULL AUTO_INCREMENT,
`equ_nom` varchar(100) NOT NULL,
`equ_ville` varchar(100) NOT NULL,
`equ_pays` varchar(50) NOT NULL,
PRIMARY KEY (`idEquipe`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Listage des données de la table rugby.equipe : ~4 rows (environ)

DELETE FROM `equipe`;
/*!40000 ALTER TABLE `equipe` DISABLE KEYS */;
INSERT INTO `equipe` (`idEquipe`, `equ_nom`, `equ_ville`, `equ_pays`) VALUES
(1, 'TOEC', 'Toulouse', 'France'),
(2, 'Stade Rochelais', 'La Rochelle', 'France'),
(3, 'Union Bordeaux-Bègles', 'Bordeaux', 'France'),
(4, 'Montpellier Hérault Rugby', 'Montpellier', 'France'),
(5, 'Rugby Club Toulonnais', 'Toulon', 'France'),
(6, 'Lyon Olympique Universitaire Rugby', 'Lyon', 'France'),
(7, 'Racing 92', 'Paris', 'France'),
(8, 'Stade Français Paris Rugby', 'Paris', 'France'),
(9, 'ASM Clermont Auvergne', 'Clermont', 'France');

/*!40000 ALTER TABLE `equipe` ENABLE KEYS */;

-- Listage de la structure de la table rugby. internaute
DROP TABLE IF EXISTS `internaute`;
CREATE TABLE IF NOT EXISTS `internaute` (
`idInternaute` int(11) NOT NULL AUTO_INCREMENT,
`int_nom` varchar(30) NOT NULL,
`int_prenom` varchar(30) NOT NULL,
`int_motPasse` varchar(155) NOT NULL,
`int_email` varchar(40) NOT NULL,
`int_pseudo` varchar(30) NOT NULL,
`int_pays` varchar(45) DEFAULT NULL,
PRIMARY KEY (`idInternaute`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Listage des données de la table rugby.internaute : ~4 rows (environ)

DELETE FROM `internaute`;
/*!40000 ALTER TABLE `internaute` DISABLE KEYS */;
INSERT INTO `internaute` (`idInternaute`, `int_nom`, `int_prenom`, `int_motPasse`, `int_email`, `int_pseudo`, `int_pays`) VALUES
(1, 'Stique', 'Sophie', 'azerty', 'sophie.stique@nsi.fr', 'sophie', 'France'),
(2, 'Cament', 'Medhi', '1234', 'medhi.cament@nsi.fr', 'mehdi', 'France'),
(3, 'Deuf', 'John', 'eeee', 'john.deuf@isn.fr', 'john', 'Angleterre'),
(4, 'Arne', 'Luc', 'eeee', 'luc.arne@toulouse.fr', 'luc', 'France');

/*!40000 ALTER TABLE `internaute` ENABLE KEYS */;

-- Listage de la structure de la table rugby. joueur

DROP TABLE IF EXISTS `joueur`;
CREATE TABLE IF NOT EXISTS `joueur` (
`idJoueur` int(11) NOT NULL AUTO_INCREMENT,
`jou_nom` varchar(80) NOT NULL,
`jou_prenom` varchar(80) NOT NULL,
`jou_image` varchar(80) DEFAULT NULL,
`idEquipe` int(11) DEFAULT NULL,
`codePoste` int(11) DEFAULT NULL,
PRIMARY KEY (`idJoueur`),
KEY `idEquipe` (`idEquipe`),
KEY `codePoste` (`codePoste`),
CONSTRAINT `joueur_ibfk_1` FOREIGN KEY (`idEquipe`) REFERENCES `equipe` (`idEquipe`),
CONSTRAINT `joueur_ibfk_2` FOREIGN KEY (`codePoste`) REFERENCES `poste` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Listage des données de la table rugby.joueur : ~5 rows (environ)

DELETE FROM `joueur`;
/*!40000 ALTER TABLE `joueur` DISABLE KEYS */;
INSERT INTO `joueur` (`idJoueur`, `jou_nom`, `jou_prenom`, `jou_image`, `idEquipe`, `codePoste`) VALUES
(1, 'ALDEGHERI', 'Dorian', NULL, 1, 1),
(2, 'ATONIO', 'Uini', NULL, 2, 1),
(3, 'BAILLE', 'Cyril', NULL, 1, 1),
(4, 'FALATEA', 'Sipili', NULL, 3, 1),
(5, 'HAOUAS', 'Mohamed', NULL, 4, 1),
(6, 'PRISO', 'Dany', NULL, 5, 1),
(7, 'WARDI', 'Reda', NULL, 4, 1),
(8, 'MARCHAND', 'Julien', NULL, 1, 2),
(9, 'MAUVAKA', 'Peato', NULL, 1, 2),
(10, 'CHALUREAU', 'Bastien', NULL, 4, 3),
(11, 'FLAMENT', 'Thibaud', NULL, 1, 3),
(12, 'TAOFIFENUA', 'Romain', NULL, 6, 3),
(13, 'VERHAEGHE', 'Florian', NULL, 4, 3),
(14, 'WOKI', 'Cameron', NULL, 7, 3),
(15, 'CROS', 'François', NULL, 1, 4),
(16, 'JELONCH', 'Anthony', NULL, 1, 4),
(17, 'MACALOU', 'Sekou', NULL, 8, 4),
(18, 'OLLIVON', 'Charles', NULL, 5, 4),
(19, 'ALLDRITT', 'Grégory', NULL, 2, 5),
(20, 'COUILLOUD', 'Baptiste', NULL, 6, 6),
(21, 'DUPONT', 'Antoine', NULL, 1, 6),
(22, 'LUCU', 'Maxime', NULL, 3, 6),
(23, 'JALIBERT', 'Matthieu', NULL, 3, 7),
(24, 'NTAMACK', 'Romain', NULL, 1, 7),
(25, 'DANTY', 'Jonathan', NULL, 2, 8),
(26, 'FICKOU', 'Gaël', NULL, 7, 8),
(27, 'DUMORTIER', 'Ethan', NULL, 6, 9),
(28, 'LEBEL', 'Matthis', NULL, 1, 9),
(29, 'MOEFANA', 'Yoram', NULL, 3, 9),
(30, 'PENAUD', 'Damian', NULL, 9, 9),
(31, 'RAMOS', 'Thomas', NULL, 1, 10),
(32, 'Melvyn', 'Jaminet', NULL, 1, 10);

/*!40000 ALTER TABLE `joueur` ENABLE KEYS */;

-- Listage de la structure de la table rugby. notation

DROP TABLE IF EXISTS `notation`;
CREATE TABLE IF NOT EXISTS `notation` (
`idNotation` int(11) NOT NULL AUTO_INCREMENT,
`idJoueur` int(11) NOT NULL,
`idInternaute` int(11) NOT NULL,
`note` int(2) NOT NULL,
`commentaires` text,
PRIMARY KEY (`idNotation`),
KEY `internaute_ibfk_2` (`idInternaute`),
KEY `internaute_ibfk_1` (`idJoueur`),
CONSTRAINT `internaute_ibfk_1` FOREIGN KEY (`idJoueur`) REFERENCES `joueur` (`idJoueur`),
CONSTRAINT `internaute_ibfk_2` FOREIGN KEY (`idInternaute`) REFERENCES `internaute` (`idInternaute`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Listage des données de la table rugby.notation : ~4 rows (environ)

DELETE FROM `notation`;
/*!40000 ALTER TABLE `notation` DISABLE KEYS */;
INSERT INTO `notation` (`idNotation`, `idJoueur`, `idInternaute`, `note`, `commentaires`) VALUES
(1, 2, 1, 10, 'Super Joueur'),
(2, 2, 3, 2, 'Bloody hell'),
(3, 4, 3, 10, 'awesome player'),
(4, 1, 2, 10, 'Un génie ! ');

/*!40000 ALTER TABLE `notation` ENABLE KEYS */;

-- Listage de la structure de la table rugby. poste

DROP TABLE IF EXISTS `poste`;
CREATE TABLE IF NOT EXISTS `poste` (
`code` int(11) NOT NULL AUTO_INCREMENT,
`pos_nom` varchar(45) NOT NULL DEFAULT 'Inconnu',
`pos_description` text,
PRIMARY KEY (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- Listage des données de la table rugby.poste : ~6 rows (environ)

DELETE FROM `poste`;
/*!40000 ALTER TABLE `poste` DISABLE KEYS */;
INSERT INTO `poste` (`code`, `pos_nom`, `pos_description`) VALUES
(1, 'Pilier', '1 et 3'),
(2, 'Talonneur', '2'),
(3, 'Deuxième Ligne', '4 et 5'),
(4, 'Troisième Ligne Aile', '6 et 7'),
(5, 'Troisième Ligne Centre', '8'),
(6, 'Demi de mêlée', '9'),
(7, "Demi d'Ouverture", '10'),
(8, 'Trois-quarts Centre', '12 et 13'),
(9, 'Ailier', '11 et 14'),
(10, 'Arriere', '15');

/*!40000 ALTER TABLE `poste` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;