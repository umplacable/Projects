<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="sport,rugby">
    <meta name="description" content=" Site rugby">
    <meta name="viewport" content="width=device-width">
    <title>Rugby</title>
    <link rel="icon" type="image/x-icon" href="img/favicon.ico">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/menu.css">
    <link rel="stylesheet" href="css/tableau2.css">
    <link rel="stylesheet" href="css/formulaire.css">
</head>

<body>
    <div id="navbar">
        <header>
            <img id="logo" src="img/Logo.png" alt="logo">
            <h1>Site de Joueurs</h1>
        </header>
        <nav class="navigation">
            <ul>
                <li><a href="index.php">acceuil</a></li>
                <li><a href="Joueur.php">Joueur</a></li>
                <li><a href="Equipe.php">Equipe</a></li>
                <li><a href="internaute.php">internaute</a></li>
                <li><a href="inscrire.php">inscription</a></li>
                <li><a href="connexion.php">connexion</a></li>
            </ul>
        </nav>
    </div>
    <section>
        <h2>Liste des Joueurs</h2>
        <table>
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prenom</th>
                    <th>Equipe</th>
                    <th>Poste</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $database = "rugby";
                // Create connection
                $conn = mysqli_connect($servername, $username, $password, $database);
                // Change character set to utf8
                mysqli_set_charset($conn, "utf8");
                // Check connection
                if (!$conn) {
                    die("Connection failed: " . mysqli_connect_error());
                }
                //echo "Connected successfully";
                $sql = "SELECT * FROM joueur 
                        JOIN equipe on joueur.idEquipe = equipe.idEquipe
                        Join poste on joueur.codePoste = poste.code";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    // output data of each row
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo    "<tr>
                <td>" . $row['jou_nom'] . "</td>
                <td>" . $row['jou_prenom'] . "</td>
                <td>" . $row['equ_nom'] . "</td>
                <td>" . $row['pos_nom'] . "</td>
                </tr>\n";
                    }
                } else {
                    echo "0 results";
                }

                mysqli_close($conn);
                ?>

            </tbody>
        </table>
    </section>

    <footer>
        <p>MDR™</p>
    </footer>
</body>

</html>