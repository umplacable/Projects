<?php
    if(     isset($_POST['nom']) && 
            isset($_POST['ville'])    && 
            isset($_POST['pays'])
    ){

        $nom = $_POST['nom'];
        $ville = $_POST['ville'];
        $pays = $_POST['pays'];


        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "rugby";
        // Create connection
        $conn = mysqli_connect($servername, $username, $password,$database);
        mysqli_set_charset($conn, "utf8");
        // Check connection
        if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());

        }
        //echo "Connected successfully";
        $sql = "INSERT INTO `rugby`.`equipe` (`equ_nom`, `equ_ville`, `equ_pays`) VALUES ( '$nom','$ville','$pays')";

        if (mysqli_multi_query($conn, $sql)) {
            echo "New records created successfully";
            header("location:./afficherEquipes.php");
          } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
          }
        
        } else {
            echo "<p>Toutes les données doivent être renseignées.</p>\n";
        }
    
?>
