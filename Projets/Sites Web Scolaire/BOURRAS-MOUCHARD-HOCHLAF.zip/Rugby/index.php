<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="sport,rugby">
    <meta name="description" content=" Site rugby">
    <meta name="viewport" content="width=device-width">
    <title>Rugby</title>
    <link rel="icon" type="image/x-icon" href="img/favicon.ico">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/menu.css">
    <link rel="stylesheet" href="css/tableau2.css">
    <link rel="stylesheet" href="css/formulaire.css">
</head>
<body>
<div id="navbar">
<header>
    <img id="logo" src="img/Logo.png" alt="logo">
    <h1>Site de Joueurs</h1>
</header>
<nav class="navigation">
    <ul>
        <li><a href="index.php">acceuil</a></li>
        <li><a href="Joueur.php">Joueur</a></li>
		<li><a href="Equipe.php">Equipe</a></li>
        <li><a href="internaute.php">internaute</a></li>
        <li><a href="inscrire.php">inscription</a></li>
        <li><a href="connexion.php">connexion</a></li>
    </ul>
</nav>
</div>
    <section>
        <h2>Site de Joueurs</h2>
        <p>Liste des Joueurs</p>
    </section>

    <footer>
    <p>MDR™</p>
</footer>
</body>
</html>