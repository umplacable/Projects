<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="sport,rugby">
    <meta name="description" content=" Site rugby">
    <meta name="viewport" content="width=device-width">
    <title>Rugby</title>
    <link rel="icon" type="image/x-icon" href="img/favicon.ico">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/menu.css">
    <link rel="stylesheet" href="css/tableau2.css">
    <link rel="stylesheet" href="css/formulaire.css">
</head>
<body>
<div id="navbar">
<header>
    <img id="logo" src="img/Logo.png" alt="logo">
    <h1>Site de Joueurs</h1>
</header>
<nav class="navigation">
    <ul>
        <li><a href="">acceuil</a></li>
        <li><a href="Joueur.php">Joueur</a></li>
		<li><a href="Equipe.php">Equipe</a></li>
        <li><a href="internaute.php">internaute</a></li>
        <li><a href="inscrire.php">inscription</a></li>
        <li><a href="connexion.php">connexion</a></li>
    </ul>
</nav>
</div>
    <section>
        <h2>Internaute</h2>
        <ul class="menu">
</head>
<meta charset="utf-8">
        <title>Mon Menu</title>
        <link rel="stylesheet" href="formulaire1.css">
<body>
<form method="post" action="./ajouterNoteExe.php" method="post" enctype="multipart/form-data">
            
            <label for="idJoueur">Joueur : </label>
            <select name="idjoueur">
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $database = "rugby";
                // Create connection
                $conn = mysqli_connect($servername, $username, $password, $database);
                // Change character set to utf8
                mysqli_set_charset($conn, "utf8");
                // Check connection
                if (!$conn) {
                    die("Connection failed: " . mysqli_connect_error());
                }
                //echo "Connected successfully";
                $sql = "SELECT * FROM joueur";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    // output data of each row
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<option value=" . $row['idJoueur'] . ">" . $row['jou_nom'] . " " . $row['jou_prenom'] . "</option>";
                    }
                } else {
                    echo "0 results";
                }

                mysqli_close($conn);
                ?>

            </select>
            <br>

        <label for="name">Laissez un commentaire :</label>
        <input type="text" id="commentaire" name="commentaire" required><br>

        <label for="name">Donnez une note /10:</label>
        <input type='number' id="note" name="note" min="0" max="10" required><br>
<input type="submit" value="Envoyer">

  
  
</body>
</html>

</body>   
        

  
</html>
    </section>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <section>
        <h2>Commentaires</h2>
        <table>
            <thead>
                <tr>
                    <th>internautes</th>
                    <th>joueurs</th>
                    <th>notes</th>
                    <th>commentaires</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $database = "rugby";
                // Create connection
                $conn = mysqli_connect($servername, $username, $password, $database);
                // Change character set to utf8
                mysqli_set_charset($conn, "utf8");
                // Check connection
                if (!$conn) {
                    die("Connection failed: " . mysqli_connect_error());
                }
                //echo "Connected successfully";
                $sql = "SELECT * FROM notation 
                        JOIN joueur on notation.idJoueur = joueur.idJoueur
                        Join internaute on notation.idInternaute = internaute.idInternaute";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    // output data of each row
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo    "<tr>
                <td>" . $row['int_pseudo'] . ' :' ."</td>
                <td>" . $row['jou_prenom'] .' '. $row['jou_nom'] . "</td>
                <td>" . $row['note'] . '/10' . "</td>
                <td>" . $row['commentaires'] . "</td>
                </tr>\n";
                    }
                } else {
                    echo "0 results";
                }

                mysqli_close($conn);
                ?>

            </tbody>
        </table>
    </section>
    <footer>
    <p>MDR™</p>
</footer>
</body>
</html>