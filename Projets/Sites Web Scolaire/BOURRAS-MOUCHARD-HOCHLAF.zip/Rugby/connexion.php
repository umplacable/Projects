<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="sport,rugby">
    <meta name="description" content=" Site rugby">
    <meta name="viewport" content="width=device-width">
    <title>Rugby</title>
    <link rel="icon" type="image/x-icon" href="img/favicon.ico">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/menu.css">
    <link rel="stylesheet" href="css/tableau2.css">
    <link rel="stylesheet" href="css/formulaire.css">
</head>
<body>
<div id="navbar">
<header>
    <img id="logo" src="img/Logo.png" alt="logo">
    <h1>Site de Joueurs</h1>
</header>
<nav class="navigation">
    <ul>
        <li><a href="">acceuil</a></li>
        <li><a href="Joueur.php">Joueur</a></li>
		<li><a href="Equipe.php">Equipe</a></li>
        <li><a href="internaute.php">internaute</a></li>
        <li><a href="inscrire.php">inscription</a></li>
        <li><a href="connexion.php">connexion</a></li>
    </ul>
</nav>
</div>
    <section>
        <h2>Connexion:</h2>
        <ul class="menu">
    <head>
        <meta charset="utf-8">
        <title>Mon Menu</title>
        <link rel="stylesheet" href="formulaire1.css">
    </head>
    <body>
        
        <form method="post" action="connexionExe.php" enctype="multipart/form-data">
            
            <?php if (isset($_GET['erreur'])) {?>
                <h3><?php echo $_GET["erreur"]?></h3>
            <?php } ?>

            <label for="pseudo">Pseudo :</label>
            <input type="text" id="pseudo" name="pseudo" required><br>
             
            <label for="mdp">Mot de passe :</label>
            <input type="password" id="mdp" name="mdp" required><br>
             
            <input type="submit" value="valider">
        </form>
    </body>
        
    
        </ul>

    </section>

<footer>
    <a href="img\Banana.html">
         <p>MDR™</p>
    </a>
</footer>
</body>
</html>