<?php
if (isset($_POST['idequipe'])) {

  $id = $_POST['idequipe'];
  $servername = "localhost";
  $username = "root";
  $password = "";
  $database = "rugby";
  // Create connection
  $conn = mysqli_connect($servername, $username, $password, $database);

  // Check connection
  if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }
  //echo "Connected successfully";
  $sql = "DELETE FROM equipe WHERE idEquipe=$id";
  if (mysqli_multi_query($conn, $sql)) {
    echo "Delete successfully";
    header("location:./afficherEquipes.php");
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
} else {
  echo "<p>Toutes les données doivent être renseignées.</p>\n";
}
?>