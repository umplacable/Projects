<?php
    date_default_timezone_set('UTC');
    if(     isset($_POST['nom']) && 
            isset($_POST['prenom'])    && 
            isset($_POST['mdp'])    && 
            isset($_POST['pseudo'])    && 
            isset($_POST['email']) &&
            isset($_POST['pay'])
    ){

        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $pseudo = $_POST['pseudo'];
        $pass = $_POST['mdp'];
        $email = $_POST['email'];
        $pay = $_POST['pay'];


        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "rugby";
        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $database);
        mysqli_set_charset($conn, "utf8");
        // Check connection
        if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());

        }
        //echo "Connected successfully";
        $sql = "INSERT INTO `rugby`.`internaute` (`int_nom`, `int_prenom`, `int_motPasse`, `int_email`, `int_pseudo`, `int_pays`) 
                VALUES ('$nom', '$prenom', '$pass', '$email', '$pseudo', '$pay')";

        if (mysqli_multi_query($conn, $sql)) {
            echo "New records created successfully";
            header("location:connexion.php");

          } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
          }
        
        } else {
            echo "<p>Toutes les données doivent être renseignées.</p>\n";
        }
    
?>
