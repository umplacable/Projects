<?php
date_default_timezone_set('UTC');
    if(     isset($_POST['commentaire']) && 
            isset($_POST['note'])    
            

    ){if (isset($_COOKIE['idUser'])){

        $comm = $_POST['commentaire'];
        $note = $_POST['note'];
        $joueur = $_POST['idjoueur'];
        $user = $_COOKIE['idUser'];


        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "rugby";
        // Create connection
        $conn = mysqli_connect($servername, $username, $password,$database);
        mysqli_set_charset($conn, "utf8");
        // Check connection
        if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());

        }
        //echo "Connected successfully";
        $sql = "INSERT INTO `rugby`.`notation` (`idJoueur`, `idInternaute`, `note`, `commentaires`) VALUES ($joueur, $user, $note, '$comm')";

        if (mysqli_multi_query($conn, $sql)) {
            echo "New records created successfully";
            header("location:./internaute.php");
          } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
          }
        
        }else{ echo "<p>tu doit te connecté pour mêtre un commentaire</p>\n";
        }
      } else {
            echo "<p>Toutes les données doivent être renseignées.</p>\n";
        }
    
?>
